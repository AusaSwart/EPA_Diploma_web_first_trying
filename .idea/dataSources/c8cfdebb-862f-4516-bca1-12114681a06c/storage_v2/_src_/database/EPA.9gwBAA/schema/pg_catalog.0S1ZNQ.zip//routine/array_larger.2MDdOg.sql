create function array_larger(anyarray, anyarray) returns anyarray
    language internal
as
$$ array_larger $$;

comment on function array_larger(anyarray, anyarray) is 'larger of two';

