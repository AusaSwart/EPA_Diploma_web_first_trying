create function brin_bloom_summary_recv(internal) returns pg_brin_bloom_summary
    language internal
as
$$ brin_bloom_summary_recv $$;

comment on function brin_bloom_summary_recv(internal) is 'I/O';

