create function close_ps(point, lseg) returns point
    language internal
as
$$ close_ps $$;

comment on function close_ps(point, lseg) is 'implementation of ## operator';

