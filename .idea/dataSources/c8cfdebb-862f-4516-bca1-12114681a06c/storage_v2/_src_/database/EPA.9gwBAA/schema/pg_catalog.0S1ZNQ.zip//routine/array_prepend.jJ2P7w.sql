create function array_prepend(anycompatible, anycompatiblearray) returns anycompatiblearray
    language internal
as
$$ array_prepend $$;

comment on function array_prepend(anycompatible, anycompatiblearray) is 'prepend element onto front of array';

