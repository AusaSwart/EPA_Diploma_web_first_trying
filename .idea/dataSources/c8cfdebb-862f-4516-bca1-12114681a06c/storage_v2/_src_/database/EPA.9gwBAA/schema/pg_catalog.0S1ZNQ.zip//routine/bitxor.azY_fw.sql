create function bitxor(bit, bit) returns bit
    language internal
as
$$ bitxor $$;

comment on function bitxor(bit, bit) is 'implementation of # operator';

