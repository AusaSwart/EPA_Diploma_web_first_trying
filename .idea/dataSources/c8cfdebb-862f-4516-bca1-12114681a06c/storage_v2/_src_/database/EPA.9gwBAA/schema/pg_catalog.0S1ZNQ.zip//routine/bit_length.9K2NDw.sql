create function bit_length(bytea) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function bit_length(bit) is 'length in bits';

