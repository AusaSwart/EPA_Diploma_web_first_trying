create function anycompatiblearray_send(anycompatiblearray) returns bytea
    language internal
as
$$ anycompatiblearray_send $$;

comment on function anycompatiblearray_send(anycompatiblearray) is 'I/O';

