create function circle_same(circle, circle) returns boolean
    language internal
as
$$ circle_same $$;

comment on function circle_same(circle, circle) is 'implementation of ~= operator';

