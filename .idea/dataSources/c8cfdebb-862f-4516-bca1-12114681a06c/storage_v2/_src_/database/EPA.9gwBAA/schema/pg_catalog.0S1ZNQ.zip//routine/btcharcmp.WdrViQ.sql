create function btcharcmp("char", "char") returns integer
    language internal
as
$$ btcharcmp $$;

comment on function btcharcmp("char", "char") is 'less-equal-greater';

