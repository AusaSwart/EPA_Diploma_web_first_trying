create function char_length(text) returns integer
    language internal
as
$$ textlen $$;

comment on function char_length(bpchar) is 'character length';

