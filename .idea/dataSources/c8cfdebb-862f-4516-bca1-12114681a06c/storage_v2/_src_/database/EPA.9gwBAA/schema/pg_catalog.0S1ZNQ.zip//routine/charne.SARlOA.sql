create function charne("char", "char") returns boolean
    language internal
as
$$ charne $$;

comment on function charne("char", "char") is 'implementation of <> operator';

