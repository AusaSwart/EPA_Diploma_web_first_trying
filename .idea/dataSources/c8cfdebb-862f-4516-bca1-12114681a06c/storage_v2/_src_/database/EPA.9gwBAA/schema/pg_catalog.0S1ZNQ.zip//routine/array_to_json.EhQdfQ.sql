create function array_to_json(anyarray) returns json
    language internal
as
$$ array_to_json $$;

comment on function array_to_json(anyarray) is 'map array to json';

