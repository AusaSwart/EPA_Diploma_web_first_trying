create function bytealike(bytea, bytea) returns boolean
    language internal
as
$$ bytealike $$;

comment on function bytealike(bytea, bytea) is 'implementation of ~~ operator';

