create function circle_contain(circle, circle) returns boolean
    language internal
as
$$ circle_contain $$;

comment on function circle_contain(circle, circle) is 'implementation of @> operator';

