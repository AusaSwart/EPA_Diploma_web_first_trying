create function box_same(box, box) returns boolean
    language internal
as
$$ box_same $$;

comment on function box_same(box, box) is 'implementation of ~= operator';

