create function array_positions(anycompatiblearray, anycompatible) returns integer[]
    language internal
as
$$ array_positions $$;

comment on function array_positions(anycompatiblearray, anycompatible) is 'returns an array of offsets of some value in array';

