create function bpchar("char") returns character
    language internal
as
$$ char_bpchar $$;

comment on function bpchar(name) is 'convert name to char(n)';

