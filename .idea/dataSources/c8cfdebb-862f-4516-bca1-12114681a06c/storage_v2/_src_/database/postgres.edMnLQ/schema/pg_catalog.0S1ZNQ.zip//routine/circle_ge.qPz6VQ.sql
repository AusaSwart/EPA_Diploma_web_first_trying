create function circle_ge(circle, circle) returns boolean
    language internal
as
$$ circle_ge $$;

comment on function circle_ge(circle, circle) is 'implementation of >= operator';

