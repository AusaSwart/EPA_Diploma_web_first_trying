create function box_above_eq(box, box) returns boolean
    language internal
as
$$ box_above_eq $$;

comment on function box_above_eq(box, box) is 'implementation of >^ operator';

