create function amvalidate(oid) returns boolean
    language internal
as
$$ amvalidate $$;

comment on function amvalidate(oid) is 'validate an operator class';

