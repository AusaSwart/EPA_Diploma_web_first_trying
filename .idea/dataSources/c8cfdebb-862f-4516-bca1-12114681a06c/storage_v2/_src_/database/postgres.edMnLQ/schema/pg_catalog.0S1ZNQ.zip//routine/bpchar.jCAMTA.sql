create function bpchar("char") returns character
    language internal
as
$$ char_bpchar $$;

comment on function bpchar(bpchar, int4, bool) is 'adjust char() to typmod length';

