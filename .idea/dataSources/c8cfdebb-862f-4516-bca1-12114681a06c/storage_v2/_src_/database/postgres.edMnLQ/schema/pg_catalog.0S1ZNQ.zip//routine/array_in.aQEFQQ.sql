create function array_in(cstring, oid, integer) returns anyarray
    language internal
as
$$ array_in $$;

comment on function array_in(cstring, oid, int4) is 'I/O';

