create function bit_recv(internal, oid, integer) returns bit
    language internal
as
$$ bit_recv $$;

comment on function bit_recv(internal, oid, int4) is 'I/O';

