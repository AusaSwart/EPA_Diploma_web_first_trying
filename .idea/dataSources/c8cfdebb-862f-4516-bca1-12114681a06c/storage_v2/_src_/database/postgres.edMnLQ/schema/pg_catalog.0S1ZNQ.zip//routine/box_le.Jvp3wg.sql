create function box_le(box, box) returns boolean
    language internal
as
$$ box_le $$;

comment on function box_le(box, box) is 'implementation of <= operator';

