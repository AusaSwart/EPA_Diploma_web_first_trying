create function boolrecv(internal) returns boolean
    language internal
as
$$ boolrecv $$;

comment on function boolrecv(internal) is 'I/O';

