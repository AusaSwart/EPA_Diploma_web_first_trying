create function btfloat4sortsupport(internal) returns void
    language internal
as
$$ btfloat4sortsupport $$;

comment on function btfloat4sortsupport(internal) is 'sort support';

